package tg.eplcoursandroid.covoiturage.models

data class Utilisateur(
    val uid: String,
    val email: String?,
    val nom: String?,
)