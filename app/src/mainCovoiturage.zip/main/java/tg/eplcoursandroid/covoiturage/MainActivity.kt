package tg.eplcoursandroid.covoiturage

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import tg.eplcoursandroid.covoiturage.models.Passager
import tg.eplcoursandroid.covoiturage.models.Utilisateur
import tg.eplcoursandroid.covoiturage.service.AuthService
import tg.eplcoursandroid.covoiturage.service.PassagerService
import tg.eplcoursandroid.covoiturage.service.UtilisateurService

class MainActivity : AppCompatActivity() {

    val authService = AuthService()
    val passagerService = PassagerService()
    val utilisateurService = UtilisateurService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        authService.inscrire("koffi@gmail.com", "koffiLeToutPuissant") { success, message ->
//            if (success) {
//                // Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
//                Log.d("Inscrire", "Koffi inscrit");
//            } else {
//                // Toast.makeText(this, "Erreur: $message", Toast.LENGTH_SHORT).show()
//                Log.d("Inscrire", "Koffi non inscrit");
//            }
//        }

        authService.connecter("koffi@gmail.com", "koffiLeToutPuissant") { success, message ->
            if (success) {
                // Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                Log.d("Inscrire", "Koffi connecte");
            } else {
                // Toast.makeText(this, "Erreur: $message", Toast.LENGTH_SHORT).show()
                Log.d("Inscrire", "Koffi non connecte")
            }
        }


        val currentUser = authService.getCurrentUser()
        if (currentUser != null) {
            Log.d("ChatApp", "Utilisateur connecté : ${currentUser.email}")
        } else {
            Log.d("ChatApp", "Aucun utilisateur connecté.")
        }

        val utilisateur = Utilisateur(currentUser!!.uid, currentUser.email, currentUser.displayName)
        utilisateurService.ajouterUtilisateur(utilisateur,onSuccess = {
            Log.d("MainActivity", "Utilisateur ajouté avec succès !")
        },
            onFailure = { exception ->
                Log.e("MainActivity", "Erreur lors de l'ajout de l'utilisateur : ${exception.message}")
            })
        val passager = Passager(utilisateur, "koffiKouma")
        passagerService.ajouterPassager(passager,onSuccess = {
            Log.d("MainActivity", "Utilisateur ajouté avec succès !")
        },
            onFailure = { exception ->
                Log.e("MainActivity", "Erreur lors de l'ajout de l'utilisateur : ${exception.message}")
            })

    }
}